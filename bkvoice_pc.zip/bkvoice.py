# -*- coding: utf-8 -*-
"""
BK보이스 — 내 PC의 GPT-SoVITS로 '내 목소리' 음성을 만들어 휴대폰(BK쇼츠)으로 보내 주는 작은 프로그램
 · GPT-SoVITS 폴더(go-webui.bat 이 있는 곳)에 넣고 'BK보이스_시작.bat' 을 더블클릭
 · 휴대폰 브라우저에서 화면에 나온 주소로 접속 (같은 와이파이 / Tailscale 원격)
 · 파이썬 기본 기능만 사용 (추가 설치 없음)
만든 곳: BK Agent · 비케이
"""
import base64, io, json, os, random, re, socket, struct, subprocess, sys, threading, time, urllib.error, urllib.parse, urllib.request, wave
from datetime import datetime
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer

VERSION = '1.0'
BASE = os.path.dirname(os.path.abspath(__file__))
DATA = os.path.join(BASE, 'bkvoice_data')
REF_DIR, TRAIN_DIR, OUT_DIR = (os.path.join(DATA, d) for d in ('ref', 'train', 'out'))
CFG_FILE = os.path.join(DATA, 'config.json')
LOG_FILE = os.path.join(DATA, 'api_log.txt')
for d in (DATA, REF_DIR, TRAIN_DIR, OUT_DIR):
    os.makedirs(d, exist_ok=True)

DEF = {'pin': '', 'port': 9870, 'api_port': 9880, 'host': '0.0.0.0', 'ref_audio': '', 'prompt_text': '',
       'gpt': '', 'sovits': '', 'speed': 1.0, 'gap': 0.35, 'lang': 'ko', 'top_k': 15, 'temperature': 1.0}


def load_cfg():
    c = dict(DEF)
    try:
        with open(CFG_FILE, encoding='utf-8') as f:
            c.update(json.load(f))
    except Exception:
        pass
    if not re.fullmatch(r'\d{4,8}', str(c.get('pin') or '')):
        c['pin'] = '%04d' % random.randint(0, 9999)
    save_cfg(c)
    return c


def save_cfg(c):
    with open(CFG_FILE, 'w', encoding='utf-8') as f:
        json.dump(c, f, ensure_ascii=False, indent=1)


CFG = load_cfg()
API = {'state': 'starting', 'msg': 'GPT-SoVITS를 켜는 중이에요 (처음엔 1~3분)', 'proc': None}
LOCK = threading.Lock()   # 그래픽카드는 한 번에 한 작업만


# ───────────────────────── GPT-SoVITS (api_v2.py) ─────────────────────────
def api_url(path):
    return 'http://127.0.0.1:%d%s' % (CFG['api_port'], path)


def api_alive():
    try:
        with urllib.request.urlopen(api_url('/docs'), timeout=3) as r:
            return r.status == 200
    except Exception:
        return False


def api_get(path, timeout=120):
    try:
        with urllib.request.urlopen(api_url(path), timeout=timeout) as r:
            return True, r.read().decode('utf-8', 'replace')
    except urllib.error.HTTPError as e:
        return False, e.read().decode('utf-8', 'replace')
    except Exception as e:
        return False, str(e)


def apply_weights():
    msgs = []
    for key, ep in (('gpt', '/set_gpt_weights'), ('sovits', '/set_sovits_weights')):
        p = CFG.get(key)
        if p:
            ok, m = api_get(ep + '?weights_path=' + urllib.parse.quote(os.path.join(BASE, p)))
            if not ok:
                msgs.append('%s 모델을 불러오지 못했어요: %s' % (key.upper(), m[:200]))
    return msgs


def start_api():
    if api_alive():
        API.update(state='ready', msg='GPT-SoVITS가 이미 켜져 있어요')
        apply_weights()
        return
    if not os.path.exists(os.path.join(BASE, 'api_v2.py')):
        API.update(state='error', msg='api_v2.py 가 없어요. BK보이스 파일을 GPT-SoVITS 폴더(go-webui.bat 있는 곳)에 넣어 주세요.')
        return
    env = dict(os.environ)
    rt = os.path.join(BASE, 'runtime')
    if os.path.isdir(rt):
        env['PATH'] = rt + os.pathsep + env.get('PATH', '')
    cmd = [sys.executable, 'api_v2.py', '-a', '127.0.0.1', '-p', str(CFG['api_port']), '-c', 'GPT_SoVITS/configs/tts_infer.yaml']
    log = open(LOG_FILE, 'w', encoding='utf-8', errors='replace')
    flags = getattr(subprocess, 'CREATE_NO_WINDOW', 0)
    try:
        API['proc'] = subprocess.Popen(cmd, cwd=BASE, env=env, stdout=log, stderr=subprocess.STDOUT, creationflags=flags)
    except Exception as e:
        API.update(state='error', msg='GPT-SoVITS를 켜지 못했어요: %s' % e)
        return
    t0 = time.time()
    while time.time() - t0 < 600:
        if API['proc'].poll() is not None:
            API.update(state='error', msg='GPT-SoVITS가 꺼졌어요. bkvoice_data\\api_log.txt 를 확인해 주세요.')
            return
        if api_alive():
            errs = apply_weights()
            API.update(state='ready', msg='준비 완료' + (' · ' + ' / '.join(errs) if errs else ''))
            return
        time.sleep(2)
    API.update(state='error', msg='GPT-SoVITS가 10분 안에 켜지지 않았어요. api_log.txt 를 확인해 주세요.')


# ───────────────────────── 문장 나누기 · 음성 만들기 ─────────────────────────
def split_sentences(text):
    text = re.sub(r'[*#_`>\[\]{}|~^■□▶•◆◇★☆※]', ' ', text.replace('\r', ''))
    out = []
    lines = [re.sub(r'\s+', ' ', l).strip() for l in text.split('\n')]
    lines = [l for l in lines if l]
    if len(lines) >= 2:      # 여러 줄이면 '한 줄 = 한 문장' (BK쇼츠 자막과 1:1로 맞춤)
        return lines
    for line in lines:
        parts = re.findall(r'[^.!?。…]+(?:[.!?。…]+|$)', line)
        for p in parts:
            p = p.strip()
            if p:
                out.append(p)
    merged = []
    for s in out:      # 너무 짧은 조각은 앞 문장에 붙임
        if merged and len(re.sub(r'\W', '', s)) < 4:
            merged[-1] += ' ' + s
        else:
            merged.append(s)
    return merged


def read_wav(b):
    with wave.open(io.BytesIO(b), 'rb') as w:
        return w.getnchannels(), w.getsampwidth(), w.getframerate(), w.readframes(w.getnframes())


def wav_bytes(ch, sw, sr, frames, extra=None):
    bio = io.BytesIO()
    with wave.open(bio, 'wb') as w:
        w.setnchannels(ch); w.setsampwidth(sw); w.setframerate(sr); w.writeframes(frames)
    data = bio.getvalue()
    if extra:   # BK쇼츠가 읽는 문장 시간표 (RIFF 'bkts' 덩어리 · 다른 프로그램은 무시)
        payload = json.dumps(extra, ensure_ascii=False).encode('utf-8')
        if len(payload) % 2:
            payload += b' '
        data += b'bkts' + struct.pack('<I', len(payload)) + payload
        data = data[:4] + struct.pack('<I', len(data) - 8) + data[8:]
    return data


def tts_one(s, speed):
    body = {'text': s, 'text_lang': CFG['lang'], 'ref_audio_path': os.path.join(BASE, CFG['ref_audio']),
            'prompt_text': CFG['prompt_text'], 'prompt_lang': CFG['lang'], 'text_split_method': 'cut0',
            'batch_size': 1, 'media_type': 'wav', 'streaming_mode': False, 'speed_factor': float(speed),
            'top_k': int(CFG['top_k']), 'top_p': 1, 'temperature': float(CFG['temperature'])}
    req = urllib.request.Request(api_url('/tts'), data=json.dumps(body).encode('utf-8'), headers={'Content-Type': 'application/json'})
    try:
        with urllib.request.urlopen(req, timeout=300) as r:
            return r.read()
    except urllib.error.HTTPError as e:
        raise RuntimeError('음성 만들기 실패: ' + e.read().decode('utf-8', 'replace')[:300])


def make_voice(text, speed):
    sents = split_sentences(text)
    if not sents:
        raise RuntimeError('읽을 문장이 없어요')
    if not CFG['ref_audio'] or not os.path.exists(os.path.join(BASE, CFG['ref_audio'])):
        raise RuntimeError('기준 음성이 없어요. ⚙ 설정에서 내 목소리 기준 음성(3~10초)을 올려 주세요.')
    fmt, chunks, segs, t = None, [], [], 0.0
    gap = max(0.0, float(CFG['gap']))
    with LOCK:
        for i, s in enumerate(sents):
            ch, sw, sr, fr = read_wav(tts_one(s, speed))
            if fmt is None:
                fmt = (ch, sw, sr)
            elif (ch, sw, sr) != fmt:
                raise RuntimeError('음성 형식이 섞였어요')
            dur = len(fr) / (ch * sw * sr)
            segs.append({'s': round(t, 3), 'e': round(t + dur, 3), 't': s})
            chunks.append(fr)
            t += dur
            if i < len(sents) - 1:
                n = int(gap * sr)
                chunks.append(b'\x00' * (n * ch * sw))
                t += n / sr
    ch, sw, sr = fmt
    return wav_bytes(ch, sw, sr, b''.join(chunks), {'v': 1, 'segs': segs}), segs


# ───────────────────────── 파일 목록 ─────────────────────────
def rel(p):
    return os.path.relpath(p, BASE).replace('\\', '/')


def list_files():
    def walk(prefix, exts):
        out = []
        for d in sorted(os.listdir(BASE)):
            if d.startswith(prefix) and os.path.isdir(os.path.join(BASE, d)):
                for root, _, fs in os.walk(os.path.join(BASE, d)):
                    out += [rel(os.path.join(root, f)) for f in sorted(fs) if f.lower().endswith(exts)]
        return out
    ref = [rel(os.path.join(REF_DIR, f)) for f in sorted(os.listdir(REF_DIR)) if f.lower().endswith(('.wav', '.mp3', '.m4a', '.flac', '.ogg'))]
    train = [f for f in sorted(os.listdir(TRAIN_DIR))]
    return {'ref': ref, 'train': train, 'train_dir': TRAIN_DIR,
            'gpt': walk('GPT_weights', ('.ckpt',)), 'sovits': walk('SoVITS_weights', ('.pth',))}


def wav_len(path):
    try:
        with wave.open(path, 'rb') as w:
            return w.getnframes() / w.getframerate()
    except Exception:
        return None


# ───────────────────────── 웹 서버 ─────────────────────────
class H(BaseHTTPRequestHandler):
    server_version = 'BKVoice/' + VERSION

    def log_message(self, fmt, *a):
        pass

    def cors(self):
        self.send_header('Access-Control-Allow-Origin', '*')
        self.send_header('Access-Control-Allow-Headers', 'Content-Type, X-BK-PIN')
        self.send_header('Access-Control-Allow-Methods', 'GET, POST, OPTIONS')
        self.send_header('Access-Control-Allow-Private-Network', 'true')
        self.send_header('Access-Control-Expose-Headers', 'X-BK-Segs')

    def send(self, code, body, ctype='application/json; charset=utf-8', extra=None):
        if isinstance(body, (dict, list)):
            body = json.dumps(body, ensure_ascii=False).encode('utf-8')
        elif isinstance(body, str):
            body = body.encode('utf-8')
        self.send_response(code)
        self.cors()
        self.send_header('Content-Type', ctype)
        self.send_header('Content-Length', str(len(body)))
        self.send_header('Cache-Control', 'no-store')
        for k, v in (extra or {}).items():
            self.send_header(k, v)
        self.end_headers()
        self.wfile.write(body)

    def do_OPTIONS(self):
        self.send_response(204)
        self.cors()
        self.send_header('Content-Length', '0')
        self.end_headers()

    def pin_ok(self, q=None):
        p = self.headers.get('X-BK-PIN') or (q or {}).get('pin', [''])[0]
        return str(p) == str(CFG['pin'])

    def body(self):
        n = int(self.headers.get('Content-Length') or 0)
        if n > 60 * 1048576:
            raise RuntimeError('파일이 너무 커요 (60MB 이하)')
        return self.rfile.read(n) if n else b''

    def do_GET(self):
        u = urllib.parse.urlparse(self.path)
        q = urllib.parse.parse_qs(u.query)
        if u.path in ('/', '/index.html'):
            return self.send(200, PAGE.replace('__VER__', VERSION), 'text/html; charset=utf-8')
        if u.path == '/api/status':
            return self.send(200, {'app': 'bkvoice', 'version': VERSION, 'api': API['state'], 'msg': API['msg'],
                                   'pin_ok': self.pin_ok(q), 'ref': CFG['ref_audio'], 'ref_ok': bool(CFG['ref_audio']) and os.path.exists(os.path.join(BASE, CFG['ref_audio']))})
        if not self.pin_ok(q):
            return self.send(403, {'error': 'PIN 번호가 맞지 않아요'})
        if u.path == '/api/config':
            c = {k: v for k, v in CFG.items() if k != 'pin'}
            return self.send(200, {'config': c, 'files': list_files()})
        if u.path.startswith('/api/out/'):
            f = os.path.join(OUT_DIR, os.path.basename(urllib.parse.unquote(u.path[9:])))
            if os.path.exists(f):
                with open(f, 'rb') as fh:
                    return self.send(200, fh.read(), 'audio/wav')
        return self.send(404, {'error': '없는 주소예요'})

    def do_POST(self):
        u = urllib.parse.urlparse(self.path)
        q = urllib.parse.parse_qs(u.query)
        if not self.pin_ok(q):
            return self.send(403, {'error': 'PIN 번호가 맞지 않아요'})
        try:
            if u.path == '/api/tts':
                if API['state'] != 'ready':
                    return self.send(503, {'error': API['msg']})
                d = json.loads(self.body() or b'{}')
                speed = float(d.get('speed') or CFG['speed'])
                data, segs = make_voice(str(d.get('text') or ''), speed)
                name = 'BK보이스_%s.wav' % datetime.now().strftime('%Y%m%d_%H%M%S')
                with open(os.path.join(OUT_DIR, name), 'wb') as f:
                    f.write(data)
                return self.send(200, data, 'audio/wav', {'X-BK-Segs': base64.b64encode(json.dumps(segs, ensure_ascii=False).encode('utf-8')).decode('ascii')})
            if u.path == '/api/upload':
                kind = (q.get('kind') or ['ref'])[0]
                name = os.path.basename((q.get('name') or ['voice.wav'])[0]) or 'voice.wav'
                name = re.sub(r'[\\/:*?"<>|]', '_', name)
                dst = os.path.join(REF_DIR if kind == 'ref' else TRAIN_DIR, name)
                with open(dst, 'wb') as f:
                    f.write(self.body())
                res = {'ok': True, 'path': rel(dst)}
                if kind == 'ref':
                    L = wav_len(dst)
                    res['seconds'] = L
                    if L is not None and not (3 <= L <= 10):
                        res['warn'] = '기준 음성은 3~10초여야 해요 (지금 %.1f초)' % L
                return self.send(200, res)
            if u.path == '/api/config':
                d = json.loads(self.body() or b'{}')
                for k in ('ref_audio', 'prompt_text', 'gpt', 'sovits', 'speed', 'gap', 'lang', 'top_k', 'temperature'):
                    if k in d:
                        CFG[k] = d[k]
                if re.fullmatch(r'\d{4,8}', str(d.get('new_pin') or '')):
                    CFG['pin'] = str(d['new_pin'])
                save_cfg(CFG)
                errs = apply_weights() if API['state'] == 'ready' else []
                return self.send(200, {'ok': not errs, 'msg': ' / '.join(errs) or '저장했어요'})
            if u.path == '/api/restart':
                p = API.get('proc')
                if p and p.poll() is None:
                    p.terminate()
                API.update(state='starting', msg='GPT-SoVITS를 다시 켜는 중이에요')
                threading.Thread(target=start_api, daemon=True).start()
                return self.send(200, {'ok': True})
        except Exception as e:
            return self.send(500, {'error': str(e)})
        return self.send(404, {'error': '없는 주소예요'})


def my_addrs():
    ips = set()
    try:
        for info in socket.getaddrinfo(socket.gethostname(), None, socket.AF_INET):
            ips.add(info[4][0])
    except Exception:
        pass
    try:
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        s.connect(('8.8.8.8', 80))
        ips.add(s.getsockname()[0])
        s.close()
    except Exception:
        pass
    return sorted(ip for ip in ips if not ip.startswith('127.'))


PAGE = r'''<!DOCTYPE html><html lang="ko"><head><meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1">
<title>BK보이스</title><meta name="theme-color" content="#0f766e">
<style>
:root{--c:#0f766e;--bg:#f0fdfa;--ink:#0f172a;--mut:#64748b}
*{box-sizing:border-box}body{margin:0;background:var(--bg);color:var(--ink);font:16px/1.6 system-ui,-apple-system,"Malgun Gothic","Apple SD Gothic Neo",sans-serif}
main{max-width:640px;margin:0 auto;padding:14px 16px 40px}
header{background:linear-gradient(135deg,#115e59,#0f766e 55%,#14b8a6);color:#fff;border-radius:20px;padding:18px 18px 16px}
header h1{margin:0;font-size:1.5rem}header p{margin:4px 0 0;opacity:.9;font-size:.92rem}
section{background:#fff;border:1px solid #ccfbf1;border-radius:18px;padding:14px;margin-top:12px}
h2{margin:0 0 8px;font-size:1.1rem;color:#115e59}
textarea,input,select{width:100%;font:inherit;padding:11px;border:1px solid #cbd5e1;border-radius:12px;background:#fff;color:var(--ink)}
textarea{min-height:190px;line-height:1.7}
button,.btn{display:block;width:100%;border:0;border-radius:14px;padding:14px;font:inherit;font-weight:800;background:var(--c);color:#fff;margin-top:10px;text-align:center;text-decoration:none;cursor:pointer}
button.sub,.btn.sub{background:#ccfbf1;color:#115e59}button:disabled{opacity:.5}
.row{display:grid;grid-template-columns:1fr 1fr;gap:8px}.small{font-size:.86rem;color:var(--mut)}
.st{padding:10px 12px;border-radius:12px;font-weight:700}.st.ok{background:#dcfce7;color:#166534}.st.wait{background:#fef9c3;color:#854d0e}.st.err{background:#fee2e2;color:#991b1b}
audio{width:100%;margin-top:10px}.segs{margin:8px 0 0;padding-left:20px;font-size:.88rem;color:#334155}
details summary{cursor:pointer;font-weight:800;color:#115e59}label{display:block;font-weight:700;margin-top:10px}
footer{text-align:center;color:var(--mut);font-size:.85rem;margin-top:18px}
</style></head><body><main>
<header><h1>🎙 BK보이스</h1><p>내 PC가 만드는 '내 목소리' · BK쇼츠 짝꿍 · v__VER__</p></header>
<section><div id="st" class="st wait">상태 확인 중…</div></section>
<section id="pinBox" hidden><h2>🔐 PIN 번호</h2><p class="small">PC 검은 창에 보이는 숫자 4자리를 넣어 주세요. (이 휴대폰에 기억돼요)</p>
<input id="pin" inputmode="numeric" placeholder="예: 1234"><button id="pinGo">확인</button></section>
<section><h2>📝 읽을 대본</h2><p class="small">BK쇼츠의 ‘📋 읽기용 대본 복사’로 복사한 글을 붙여넣어요. 한 줄 = 한 문장(자막 한 장면)이에요.</p>
<textarea id="txt" placeholder="안녕하세요 1분 뉴스입니다.&#10;오늘은 …"></textarea>
<div class="row"><div><label>말 빠르기</label><select id="speed"><option value="0.9">조금 느리게</option><option value="1" selected>보통</option><option value="1.1">조금 빠르게</option><option value="1.2">빠르게</option></select></div>
<div><label>&nbsp;</label><button id="paste" class="sub" style="margin-top:0">📋 붙여넣기</button></div></div>
<button id="go">🔊 내 목소리로 만들기</button><p class="small" id="goMsg"></p>
<div id="res" hidden><audio id="au" controls></audio><a id="dl" class="btn" download>💾 휴대폰에 저장 (BK쇼츠에서 불러오기)</a><ol class="segs" id="segs"></ol></div></section>
<section><details id="setBox"><summary>⚙ 설정 (기준 음성 · 학습한 모델)</summary>
<label>① 기준 음성 올리기 <span class="small">(내 목소리 3~10초 WAV · BK쇼츠 ‘기준 음성 녹음’으로 만든 파일)</span></label>
<input type="file" id="refFile" accept="audio/*,.wav"><p class="small" id="refMsg"></p>
<label>기준 음성 고르기</label><select id="refSel"></select>
<label>기준 음성에서 읽은 문장 <span class="small">(글자 그대로)</span></label><input id="prompt" placeholder="안녕하세요, 오늘도 쉽고 정확한 소식을 전해 드리겠습니다.">
<label>② 학습한 GPT 모델 <span class="small">(GPT_weights 폴더 · 학습 전이면 ‘기본’)</span></label><select id="gpt"></select>
<label>학습한 SoVITS 모델 <span class="small">(SoVITS_weights 폴더)</span></label><select id="sovits"></select>
<label>문장 사이 쉬는 시간</label><select id="gap"><option value="0.2">짧게 (0.2초)</option><option value="0.35">보통 (0.35초)</option><option value="0.5">길게 (0.5초)</option></select>
<label>③ 학습용 녹음 올리기 <span class="small">(BK쇼츠 ‘학습용 녹음’ 파일 → PC의 bkvoice_data\train 폴더로)</span></label>
<input type="file" id="trFile" accept="audio/*,.wav" multiple><p class="small" id="trMsg"></p>
<button id="save">💾 설정 저장</button><button id="restart" class="sub">🔄 GPT-SoVITS 다시 켜기</button>
<label>PIN 번호 바꾸기 <span class="small">(4~8자리 숫자)</span></label><input id="newPin" inputmode="numeric" placeholder="새 PIN (비워 두면 그대로)">
</details></section>
<footer>BK보이스 · BK Agent · 비케이<br>이 화면은 내 PC에서만 열려요. 본인 목소리만 사용해 주세요.</footer>
</main><script>
(function(){
const $=i=>document.getElementById(i);let PIN='';try{PIN=localStorage.getItem('bkvPin')||''}catch(e){}
const H=()=>({'Content-Type':'application/json','X-BK-PIN':PIN});
async function j(u,o){const r=await fetch(u,o);let d={};try{d=await r.json()}catch(e){}if(!r.ok)throw new Error(d.error||('오류 '+r.status));return d}
function st(c,t){const e=$('st');e.className='st '+c;e.textContent=t}
async function status(){try{const d=await j('/api/status?pin='+encodeURIComponent(PIN));
 $('pinBox').hidden=d.pin_ok;if(!d.pin_ok){st('wait','🔐 PIN 번호를 넣어 주세요');return d}
 if(d.api==='ready')st(d.ref_ok?'ok':'wait',d.ref_ok?'✅ 준비 완료 · 대본을 넣고 만들어요':'⚠️ 기준 음성이 없어요 · 아래 ⚙ 설정에서 올려 주세요');
 else if(d.api==='error')st('err','❌ '+d.msg);else st('wait','⏳ '+d.msg);
 if(!d.ref_ok)$('setBox').open=true;return d}catch(e){st('err','❌ PC에 연결이 안 돼요: '+e.message)}}
async function loadCfg(){try{const d=await j('/api/config?pin='+encodeURIComponent(PIN));const c=d.config,f=d.files;
 const opt=(sel,list,cur,def)=>{$(sel).innerHTML=(def?'<option value="">'+def+'</option>':'')+list.map(x=>'<option'+(x===cur?' selected':'')+'>'+x+'</option>').join('')};
 opt('refSel',f.ref,c.ref_audio,f.ref.length?'':'(아직 없음)');opt('gpt',f.gpt,c.gpt,'기본 (학습 전)');opt('sovits',f.sovits,c.sovits,'기본 (학습 전)');
 $('prompt').value=c.prompt_text||'';$('gap').value=String(c.gap);$('speed').value=String(c.speed);
 $('trMsg').textContent=f.train.length?('PC에 있는 학습용 녹음: '+f.train.join(', ')+' → 폴더: '+f.train_dir):'';}catch(e){}}
$('pinGo').onclick=async()=>{PIN=$('pin').value.trim();try{localStorage.setItem('bkvPin',PIN)}catch(e){}const d=await status();if(d&&d.pin_ok)loadCfg()};
$('paste').onclick=async()=>{try{$('txt').value=await navigator.clipboard.readText()}catch(e){alert('붙여넣기 칸을 길게 눌러 붙여넣어 주세요')}};
try{const h=decodeURIComponent((location.hash.match(/[#&]t=([^&]*)/)||[])[1]||'');if(h)$('txt').value=h}catch(e){}
$('go').onclick=async()=>{const t=$('txt').value.trim();if(!t){alert('대본을 넣어 주세요');return}
 $('go').disabled=true;$('goMsg').textContent='⏳ 만드는 중… (문장마다 1~3초)';$('res').hidden=true;const t0=Date.now();
 try{const r=await fetch('/api/tts',{method:'POST',headers:H(),body:JSON.stringify({text:t,speed:$('speed').value})});
  if(!r.ok){let d={};try{d=await r.json()}catch(e){}throw new Error(d.error||('오류 '+r.status))}
  const b=await r.blob(),u=URL.createObjectURL(b);let segs=[];try{segs=JSON.parse(new TextDecoder().decode(Uint8Array.from(atob(r.headers.get('X-BK-Segs')||''),c=>c.charCodeAt(0))))}catch(e){}
  $('au').src=u;const d=new Date(),p=n=>String(n).padStart(2,'0');$('dl').href=u;$('dl').download='BK보이스_'+d.getFullYear()+p(d.getMonth()+1)+p(d.getDate())+'_'+p(d.getHours())+p(d.getMinutes())+'.wav';
  $('segs').innerHTML=segs.map(s=>'<li>'+s.s.toFixed(1)+'초 · '+s.t.replace(/</g,'&lt;')+'</li>').join('');$('res').hidden=false;
  $('goMsg').textContent='✅ 완성 ('+Math.round((Date.now()-t0)/1000)+'초) · 들어 보고 💾 저장하세요'}
 catch(e){$('goMsg').textContent='❌ '+e.message}finally{$('go').disabled=false}};
async function up(file,kind){const r=await fetch('/api/upload?kind='+kind+'&name='+encodeURIComponent(file.name),{method:'POST',headers:{'X-BK-PIN':PIN},body:file});const d=await r.json();if(!r.ok)throw new Error(d.error);return d}
$('refFile').onchange=async e=>{const f=e.target.files[0];if(!f)return;$('refMsg').textContent='올리는 중…';try{const d=await up(f,'ref');$('refMsg').textContent=(d.warn?'⚠️ '+d.warn:'✅ 올렸어요'+(d.seconds?' ('+d.seconds.toFixed(1)+'초)':''));await loadCfg();$('refSel').value=d.path}catch(err){$('refMsg').textContent='❌ '+err.message}};
$('trFile').onchange=async e=>{const fs=[...e.target.files];for(const f of fs){$('trMsg').textContent='올리는 중… '+f.name;try{await up(f,'train')}catch(err){$('trMsg').textContent='❌ '+err.message;return}}loadCfg()};
$('save').onclick=async()=>{try{const d=await j('/api/config',{method:'POST',headers:H(),body:JSON.stringify({ref_audio:$('refSel').value,prompt_text:$('prompt').value.trim(),gpt:$('gpt').value,sovits:$('sovits').value,gap:parseFloat($('gap').value),speed:parseFloat($('speed').value),new_pin:$('newPin').value.trim()})});
 if($('newPin').value.trim()){PIN=$('newPin').value.trim();try{localStorage.setItem('bkvPin',PIN)}catch(e){}$('newPin').value=''}alert(d.ok?'✅ 저장했어요':'⚠️ '+d.msg);status()}catch(e){alert('❌ '+e.message)}};
$('restart').onclick=async()=>{try{await j('/api/restart',{method:'POST',headers:H()});st('wait','⏳ 다시 켜는 중…')}catch(e){alert(e.message)}};
status().then(d=>{if(d&&d.pin_ok)loadCfg()});setInterval(()=>{if(!$('go').disabled)status()},8000);
})();
</script></body></html>'''


def main():
    try:
        sys.stdout.reconfigure(encoding='utf-8', errors='replace')
    except Exception:
        pass
    threading.Thread(target=start_api, daemon=True).start()
    srv = ThreadingHTTPServer((CFG['host'], int(CFG['port'])), H)
    line = '=' * 56
    print(line)
    print('  BK보이스 v%s  (이 창을 닫으면 꺼져요)' % VERSION)
    print(line)
    print('  PIN 번호 :  %s' % CFG['pin'])
    print('  이 PC    :  http://localhost:%d' % CFG['port'])
    for ip in my_addrs():
        tag = '  ← Tailscale(외출 중)' if ip.startswith('100.') else '  ← 같은 와이파이'
        print('  휴대폰   :  http://%s:%d%s' % (ip, CFG['port'], tag))
    print('  처음 켤 때 GPT-SoVITS 준비에 1~3분 걸려요.')
    print(line)
    try:
        srv.serve_forever()
    except KeyboardInterrupt:
        pass
    finally:
        p = API.get('proc')
        if p and p.poll() is None:
            p.terminate()


if __name__ == '__main__':
    main()
